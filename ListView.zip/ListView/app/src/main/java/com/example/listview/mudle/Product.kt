package com.example.listview.mudle

class Product(var title:String , var price:String , var image :String) {

}