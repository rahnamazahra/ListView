package com.example.listview.mudle

import android.icu.text.CaseMap

class Category(var title:String , var image:String) {
    override fun toString(): String {
        return title
    }
}