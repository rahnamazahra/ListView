package com.example.listview.Controller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.listview.Adapters.CategoryAdapter
import com.example.listview.R
import com.example.listview.Services.DataService
import com.example.listview.mudle.Category
import com.example.listview.mudle.Product
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var categoriesAdapter : CategoryAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        categoriesAdapter = CategoryAdapter(this,DataService.categories)
        CategoryListView.adapter = categoriesAdapter

        CategoryListView.setOnItemClickListener { adapterView, view, i, l ->
            Toast.makeText(this,DataService.categories[i].title , Toast.LENGTH_LONG).show()
        }

    }
}